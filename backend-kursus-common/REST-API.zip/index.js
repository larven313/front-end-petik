const express = require("express");
const cors = require("cors");
const fileUpload = require("express-fileupload");
const bodyParser = require("body-parser");
const CourseRouter = require("./routes/CourseRoute.js");
const TrainerRoute = require("./routes/TrainerRoute.js");

const app = express();

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(fileUpload());
app.use(CourseRouter);
app.use(TrainerRoute);
app.use(express.static("public"));

app.listen(process.env.port || 5000, "localhost", () =>
  console.log("Server Running in port 5000")
);
